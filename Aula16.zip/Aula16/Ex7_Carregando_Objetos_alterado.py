# Ex7_Carregando_Objeto.py
# Renderiza um modelo OBJ com textura usando OpenGL moderno (VAO/VBO, shaders).
# Versão final para o Trabalho 03.

import glfw
from OpenGL.GL import *
import OpenGL.GL.shaders
import numpy as np
from TextureLoader import load_texture
from Camera import Camera
from ObjLoaderSimple import ObjLoaderSimple
import pyrr
from pyrr import matrix44, Vector3
import ctypes

# --- Parâmetros da janela ---
WIDTH, HEIGHT = 1200, 800

# --- Variáveis globais ---
Window = None
Shader_programm = None
cam = Camera()

# Variáveis para os objetos
vao_objeto, num_vertices, obj_textura = None, 0, None
vao_gato, num_vertices_gato, obj_textura_gato = None, 0, None
vao_pato, num_vertices_pato, textura_pato = None, 0, None
vao_cachorro, num_vertices_cachorro, textura_cachorro = None, 0, None
vao_carro, num_vertices_carro, textura_carro = None, 0, None
vao_poste, num_vertices_poste, textura_poste = None, 0, None
vao_banco, num_vertices_banco, textura_banco = None, 0, None


# ----------------------------------------
# Callbacks e Inicialização do OpenGL
# ----------------------------------------
def redimensiona_callback(window, w, h):
    global WIDTH, HEIGHT
    WIDTH, HEIGHT = w, h
    glViewport(0, 0, WIDTH, HEIGHT)

def teclado_callback(window, key, scancode, action, mods):
    if key == glfw.KEY_ESCAPE and action == glfw.PRESS:
        glfw.set_window_should_close(window, True)

first_mouse = True
lastX, lastY = WIDTH/2, HEIGHT/2

def mouse_callback(window, xpos, ypos):
    global first_mouse, lastX, lastY
    if first_mouse:
        lastX, lastY = xpos, ypos
        first_mouse = False
    xoffset = xpos - lastX
    yoffset = lastY - ypos
    lastX, lastY = xpos, ypos
    cam.process_mouse_movement(xoffset, yoffset)

def inicializa_opengl():
    global Window
    if not glfw.init(): raise RuntimeError("Falha ao inicializar GLFW")
    Window = glfw.create_window(WIDTH, HEIGHT, "Trabalho 03 - Carregando 5 Objetos", None, None)
    if not Window:
        glfw.terminate()
        raise RuntimeError("Falha ao criar janela")
    
    glfw.set_window_size_callback(Window, redimensiona_callback)
    glfw.set_key_callback(Window, teclado_callback)
    glfw.make_context_current(Window)
    glfw.set_input_mode(Window, glfw.CURSOR, glfw.CURSOR_DISABLED)
    glfw.set_cursor_pos_callback(Window, mouse_callback)
    glEnable(GL_DEPTH_TEST)
    print("OpenGL:", glGetString(GL_VERSION).decode())

# ----------------------------------------
# Carregamento dos Objetos
# ----------------------------------------
def inicializa_objeto():
    global vao_objeto, num_vertices, obj_textura
    buffer, num_vertices = ObjLoaderSimple.load_obj("meshes/chibi.obj")
    buffer = buffer.astype(np.float32)
    vao_objeto = glGenVertexArrays(1)
    glBindVertexArray(vao_objeto)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    obj_textura = glGenTextures(1)
    load_texture("textures/chibi.png", obj_textura)

def inicializa_gato():
    global vao_gato, num_vertices_gato, obj_textura_gato
    buffer, num_vertices_gato = ObjLoaderSimple.load_obj("meshes/Cat/Cat_blender.obj")
    buffer = buffer.astype(np.float32)
    vao_gato = glGenVertexArrays(1)
    glBindVertexArray(vao_gato)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    obj_textura_gato = glGenTextures(1)
    load_texture("textures/Cat_diffuse.jpg", obj_textura_gato)

### TRABALHO 03: FUNÇÕES DE INICIALIZAÇÃO PARA OS NOVOS OBJETOS ###

def inicializa_pato():
    global vao_pato, num_vertices_pato, textura_pato
    buffer, num_vertices_pato = ObjLoaderSimple.load_obj("meshes/Rubber_Duck.obj")
    buffer = buffer.astype(np.float32)
    vao_pato = glGenVertexArrays(1)
    glBindVertexArray(vao_pato)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    textura_pato = glGenTextures(1)
    load_texture("textures/Rubber_Duck_D.png", textura_pato) # ATENÇÃO: Verifique se o nome do arquivo de textura está correto

def inicializa_cachorro():
    global vao_cachorro, num_vertices_cachorro, textura_cachorro
    buffer, num_vertices_cachorro = ObjLoaderSimple.load_obj("meshes/Puppy_v1.obj")
    buffer = buffer.astype(np.float32)
    vao_cachorro = glGenVertexArrays(1)
    glBindVertexArray(vao_cachorro)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    textura_cachorro = glGenTextures(1)
    load_texture("textures/Puppy_D.jpg", textura_cachorro) # ATENÇÃO: Verifique se o nome do arquivo de textura está correto

def inicializa_carro():
    global vao_carro, num_vertices_carro, textura_carro
    buffer, num_vertices_carro = ObjLoaderSimple.load_obj("meshes/Car.obj")
    buffer = buffer.astype(np.float32)
    vao_carro = glGenVertexArrays(1)
    glBindVertexArray(vao_carro)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    textura_carro = glGenTextures(1)
    load_texture("textures/Car_D.png", textura_carro) # ATENÇÃO: Verifique se o nome do arquivo de textura está correto

def inicializa_poste():
    global vao_poste, num_vertices_poste, textura_poste
    buffer, num_vertices_poste = ObjLoaderSimple.load_obj("meshes/lamp_post_2.obj")
    buffer = buffer.astype(np.float32)
    vao_poste = glGenVertexArrays(1)
    glBindVertexArray(vao_poste)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    textura_poste = glGenTextures(1)
    load_texture("textures/lamp_post_D.jpg", textura_poste) # ATENÇÃO: Verifique se o nome do arquivo de textura está correto

def inicializa_banco():
    global vao_banco, num_vertices_banco, textura_banco
    buffer, num_vertices_banco = ObjLoaderSimple.load_obj("meshes/WoodenBench.obj")
    buffer = buffer.astype(np.float32)
    vao_banco = glGenVertexArrays(1)
    glBindVertexArray(vao_banco)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, buffer.nbytes, buffer, GL_STATIC_DRAW)
    stride = buffer.itemsize * 5
    glEnableVertexAttribArray(0)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(0))
    glEnableVertexAttribArray(1)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, ctypes.c_void_p(buffer.itemsize * 3))
    textura_banco = glGenTextures(1)
    load_texture("textures/WoodenBench_D.png", textura_banco) # ATENÇÃO: Verifique se o nome do arquivo de textura está correto

# ----------------------------------------
# Compilação dos shaders
# ----------------------------------------
def inicializa_shaders():
    global Shader_programm
    vertex_src = """#version 400
        layout(location = 0) in vec3 in_pos;
        layout(location = 1) in vec2 in_uv;
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;
        out vec2 frag_uv;
        void main() {
            frag_uv = in_uv;
            gl_Position = projection * view * model * vec4(in_pos, 1.0);
        }"""
    fragment_src = """#version 400
        in vec2 frag_uv;
        uniform sampler2D texture1;
        out vec4 FragColor;
        void main() {
            FragColor = texture(texture1, frag_uv);
        }"""
    vs = OpenGL.GL.shaders.compileShader(vertex_src, GL_VERTEX_SHADER)
    fs = OpenGL.GL.shaders.compileShader(fragment_src, GL_FRAGMENT_SHADER)
    if not glGetShaderiv(vs, GL_COMPILE_STATUS) or not glGetShaderiv(fs, GL_COMPILE_STATUS):
        raise Exception("Erro na compilação do shader")
    Shader_programm = OpenGL.GL.shaders.compileProgram(vs, fs)

# ----------------------------------------
# Loop de renderização
# ----------------------------------------
def render_loop():
    last_time = glfw.get_time()
    base_speed = 15.0

    while not glfw.window_should_close(Window):
        current_time = glfw.get_time()
        delta = current_time - last_time
        last_time = current_time
        vel = base_speed * delta

        if glfw.get_key(Window, glfw.KEY_W) == glfw.PRESS: cam.process_keyboard("FORWARD", vel)
        if glfw.get_key(Window, glfw.KEY_S) == glfw.PRESS: cam.process_keyboard("BACKWARD", vel)
        if glfw.get_key(Window, glfw.KEY_A) == glfw.PRESS: cam.process_keyboard("LEFT", vel)
        if glfw.get_key(Window, glfw.KEY_D) == glfw.PRESS: cam.process_keyboard("RIGHT", vel)

        glClearColor(0.1, 0.2, 0.3, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glUseProgram(Shader_programm)

        view = cam.get_view_matrix()
        projection = pyrr.matrix44.create_perspective_projection_matrix(45.0, WIDTH/HEIGHT, 0.1, 500.0)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "view"), 1, GL_FALSE, view)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "projection"), 1, GL_FALSE, projection)

        # --- Desenha o Chibi ---
        model_chibi = pyrr.matrix44.create_from_translation(pyrr.Vector3([0, -5, 0]))
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_chibi)
        glBindVertexArray(vao_objeto)
        glBindTexture(GL_TEXTURE_2D, obj_textura)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices)
        
        # --- Desenha o Gato ---
        trans_gato = pyrr.matrix44.create_from_translation(pyrr.Vector3([15, -5, 0]))
        rot_gato = pyrr.matrix44.create_from_x_rotation(np.radians(90))
        escala_gato = pyrr.matrix44.create_from_scale(pyrr.Vector3([0.2, 0.2, 0.2]))
        model_gato = pyrr.matrix44.multiply(pyrr.matrix44.multiply(trans_gato, rot_gato), escala_gato)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_gato)
        glBindVertexArray(vao_gato)
        glBindTexture(GL_TEXTURE_2D, obj_textura_gato)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_gato)

        ### TRABALHO 03: RENDERIZAR SEUS OBJETOS ###
        # --- Desenha o Pato (Rubber_Duck) ---
        trans_pato = pyrr.matrix44.create_from_translation(pyrr.Vector3([-15, -5, 10]))
        escala_pato = pyrr.matrix44.create_from_scale(pyrr.Vector3([2.0, 2.0, 2.0]))
        model_pato = pyrr.matrix44.multiply(trans_pato, escala_pato)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_pato)
        glBindVertexArray(vao_pato)
        glBindTexture(GL_TEXTURE_2D, textura_pato)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_pato)

        # --- Desenha o Cachorro (Puppy_v1) ---
        trans_cachorro = pyrr.matrix44.create_from_translation(pyrr.Vector3([25, -5, 15]))
        rot_cachorro = pyrr.matrix44.create_from_y_rotation(np.radians(-90))
        escala_cachorro = pyrr.matrix44.create_from_scale(pyrr.Vector3([3.0, 3.0, 3.0]))
        model_cachorro = pyrr.matrix44.multiply(pyrr.matrix44.multiply(trans_cachorro, rot_cachorro), escala_cachorro)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_cachorro)
        glBindVertexArray(vao_cachorro)
        glBindTexture(GL_TEXTURE_2D, textura_cachorro)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_cachorro)

        # --- Desenha o Carro (Car_V1) ---
        trans_carro = pyrr.matrix44.create_from_translation(pyrr.Vector3([-10, -5, -20]))
        rot_carro = pyrr.matrix44.create_from_y_rotation(np.radians(135))
        escala_carro = pyrr.matrix44.create_from_scale(pyrr.Vector3([4.0, 4.0, 4.0]))
        model_carro = pyrr.matrix44.multiply(pyrr.matrix44.multiply(trans_carro, rot_carro), escala_carro)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_carro)
        glBindVertexArray(vao_carro)
        glBindTexture(GL_TEXTURE_2D, textura_carro)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_carro)

        # --- Desenha o Poste (lamp_post_2) ---
        trans_poste = pyrr.matrix44.create_from_translation(pyrr.Vector3([40, -5, -15]))
        escala_poste = pyrr.matrix44.create_from_scale(pyrr.Vector3([5.0, 5.0, 5.0]))
        model_poste = pyrr.matrix44.multiply(trans_poste, escala_poste)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_poste)
        glBindVertexArray(vao_poste)
        glBindTexture(GL_TEXTURE_2D, textura_poste)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_poste)

        # --- Desenha o Banco (WoodenBench) ---
        trans_banco = pyrr.matrix44.create_from_translation(pyrr.Vector3([0, -5, 25]))
        rot_banco = pyrr.matrix44.create_from_y_rotation(np.radians(180))
        escala_banco = pyrr.matrix44.create_from_scale(pyrr.Vector3([4.0, 4.0, 4.0]))
        model_banco = pyrr.matrix44.multiply(pyrr.matrix44.multiply(trans_banco, rot_banco), escala_banco)
        glUniformMatrix4fv(glGetUniformLocation(Shader_programm, "model"), 1, GL_FALSE, model_banco)
        glBindVertexArray(vao_banco)
        glBindTexture(GL_TEXTURE_2D, textura_banco)
        glDrawArrays(GL_TRIANGLES, 0, num_vertices_banco)
        
        glfw.swap_buffers(Window)
        glfw.poll_events()

    glfw.terminate()

# ----------------------------------------
# Função principal
# ----------------------------------------
def main():
    inicializa_opengl()
    inicializa_shaders()
    
    # Carrega todos os modelos
    inicializa_objeto()
    inicializa_gato()
    inicializa_pato()
    inicializa_cachorro()
    inicializa_carro()
    inicializa_poste()
    inicializa_banco()
    
    render_loop()

if __name__ == "__main__":
    main()